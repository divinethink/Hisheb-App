import { useId, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { categoryColorIndex, formatAmount, formatTakaWhole } from '../../../lib/format';
import { getCategoryIcon } from '../../../lib/categoryIcons';
import { splitTrio, trioInsight, type CategoryShare, type CategoryTrioRow } from '../../../lib/overviewCalc';

// SVG url(#id) reference-এ React-এর useId() ফেরানো কোলন (":r0:") কিছু browser-এ ভাঙতে পারে —
// তাই gradient-id বানানোর সময় সবসময় এই helper দিয়ে sanitize করা হবে (alnum+dash-ই থাকবে)।
const svgId = (id: string) => id.replace(/:/g, '');

// হালকা inline SVG/CSS চার্ট — কোনো chart-library dependency নেই (bundle ও package-lock ঝুঁকি এড়াতে)।
// অর্থ শুধু রঙে নয়: প্রতিটা সারিতে নাম, পরিমাণ ও শতাংশ টেক্সটে আছে (accessibility, UI Mockup §৩.১)।

const CHART_VARS = ['--chart-1', '--chart-2', '--chart-3', '--chart-4', '--chart-5', '--chart-6', '--chart-7', '--chart-8'];
const chartVar = (name: string) => CHART_VARS[categoryColorIndex(name, CHART_VARS.length)];

export function CategoryBars({ items, onSelect }: { items: readonly CategoryShare[]; onSelect?: (name: string) => void }) {
  if (items.length === 0) return <p className="text-sm text-muted">No expenses in this period.</p>;
  return (
    <ul aria-label="Expense by category" className="flex flex-col gap-2">
      {items.map((c) => {
        const v = chartVar(c.name);
        return (
          <li key={c.name}>
            <button
              type="button"
              disabled={!onSelect}
              onClick={() => onSelect?.(c.name)}
              className="block w-full text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
            >
            <div className="flex justify-between gap-3 text-sm">
              <span className="flex min-w-0 items-center gap-2">
                <span aria-hidden className="shrink-0 text-sm leading-none">{getCategoryIcon(c.name, 'expense')}</span>
                <span className="min-w-0 truncate text-fg">{c.name}</span>
              </span>
              <span className="shrink-0 text-fg">
                {formatTakaWhole(c.totalMinor)} <span className="text-muted">· {Math.round(c.share * 100)}%</span>
              </span>
            </div>
            <div className="mt-1 h-2 rounded bg-muted/15" aria-hidden>
              <div className="h-2 rounded" style={{ width: `${Math.max(2, c.share * 100)}%`, background: `rgb(var(${v}))` }} />
            </div>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

const MONTH_SHORT_TRIO = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const PILL = 'inline-flex h-7 w-[62px] shrink-0 items-center justify-center rounded-full px-0.5 text-[11px] font-semibold tabular-nums';

function TrioRow({ r, ready, onSelect }: { r: CategoryTrioRow; ready: boolean; onSelect?: (name: string) => void }) {
  const d = r.deltaPct;
  const cur = r.minors[2];
  const hasTag = ready && cur > 0 && d != null && Math.abs(d) >= 10;
  const tone = !hasTag ? 'bg-primary/10 text-primary' : (d as number) > 0 ? 'bg-expense/15 text-expense' : 'bg-income/15 text-income';
  const arrow = hasTag ? ((d as number) > 0 ? '↑' : '↓') : '';
  const longWord = !/\s/.test(r.name.trim()) && r.name.length > 11; // এক লম্বা শব্দ: মাঝখানে না ভেঙে "…"
  return (
    <li className="border-b border-dashed border-muted/25 last:border-b-0">
      <button
        type="button"
        disabled={!onSelect || cur === 0}
        onClick={() => onSelect?.(r.name)}
        className="flex min-h-12 w-full items-center gap-1 py-1.5 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
      >
        <span className="flex min-w-0 flex-1 items-center gap-1.5">
          <span aria-hidden className="shrink-0 text-sm leading-none">{getCategoryIcon(r.name, 'expense')}</span>
          <span className={`min-w-0 overflow-hidden text-[13px] font-medium leading-tight text-fg ${longWord ? 'truncate' : 'line-clamp-2'}`}>{r.name}</span>
        </span>
        {[r.minors[0], r.minors[1]].map((v, i) => (
          <span key={i} className={`${PILL} bg-muted/10 font-medium text-muted`}>{!ready ? '…' : v > 0 ? formatTakaWhole(v) : '—'}</span>
        ))}
        <span className={`${PILL} ${cur === 0 ? 'bg-muted/10 text-muted' : tone}`}>{cur > 0 ? `${arrow}${formatTakaWhole(cur)}` : '—'}</span>
      </button>
    </li>
  );
}

/** ৩ মাসের ক্যাটাগরি-তুলনা (ডেইলি-টাস্ক চিত্রের স্টাইল): ওপরে ছোট বিশ্লেষণ, নিচে নাম + ৩টি পিল; অনিয়মিতগুলো কলাপসিবলে। */
export function CategoryTrio({
  rows,
  months,
  ready,
  inProgress,
  onSelect,
}: {
  rows: readonly CategoryTrioRow[];
  months: readonly [string, string, string]; // yyyymm × ৩
  ready: boolean; // আগের মাসের ডেটা লোড হয়েছে কি
  inProgress: boolean;
  onSelect?: (name: string) => void;
}) {
  const [open, setOpen] = useState(false);
  if (rows.length === 0) return <p className="text-sm text-muted">No expenses in this period.</p>;
  const head = months.map((m) => MONTH_SHORT_TRIO[Number(m.slice(5, 7)) - 1] ?? m);
  const { up, down } = ready ? trioInsight(rows) : { up: null, down: null };
  const { main, rest } = ready ? splitTrio(rows, inProgress) : { main: [...rows], rest: [] as CategoryTrioRow[] };
  const box = 'rounded-xl border px-3 py-2.5';
  return (
    <div className="flex flex-col gap-2.5">
      {(down || up) && (
        <div className="flex flex-col gap-2">
          {down && (
            <div className={`${box} border-income/25 bg-income/10`}>
              <p className="text-sm font-semibold text-income">🌱 Biggest drop</p>
              <p className="mt-0.5 text-xs text-fg">{down.name} is down {formatTakaWhole(down.minors[1] - down.minors[2])} from last month.</p>
            </div>
          )}
          {up && (
            <div className={`${box} border-warning/30 bg-warning/10`}>
              <p className="text-sm font-semibold text-warning">💛 Worth a look</p>
              <p className="mt-0.5 text-xs text-fg">
                {up.deltaPct == null
                  ? `${up.name} is new this month: ${formatTakaWhole(up.minors[2])}.`
                  : `${up.name} is up ${formatTakaWhole(up.minors[2] - up.minors[1])} (${Math.round(up.deltaPct)}%) from last month.`}
              </p>
            </div>
          )}
        </div>
      )}
      {inProgress && <p className="text-[11px] text-muted">* The current month is still in progress, so its figures are incomplete.</p>}
      <div>
        <div className="flex items-center gap-1 border-b border-muted/20 pb-1.5 text-[11px] text-muted" aria-hidden>
          <span className="min-w-0 flex-1">Category</span>
          {head.map((h, i) => (
            <span key={`${h}${i}`} className={`w-[62px] shrink-0 text-center ${i === 2 ? 'font-semibold text-primary' : ''}`}>{h}{i === 2 && inProgress ? '*' : ''}</span>
          ))}
        </div>
        <ul aria-label="Expense by category, last 3 months">
          {main.map((r) => <TrioRow key={r.name} r={r} ready={ready} onSelect={onSelect} />)}
        </ul>
        {rest.length > 0 && (
          <>
            <button
              type="button"
              aria-expanded={open}
              onClick={() => setOpen(!open)}
              className="mt-1 flex min-h-11 w-full items-center justify-center gap-1.5 rounded-xl bg-muted/10 text-xs font-medium text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
            >
              {open ? 'Show less' : `Other categories (${rest.length})`}
              <ChevronDown aria-hidden size={14} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
            </button>
            {open && (
              <ul aria-label="Other categories, last 3 months" className="mt-1">
                {rest.map((r) => <TrioRow key={r.name} r={r} ready={ready} onSelect={onSelect} />)}
              </ul>
            )}
          </>
        )}
      </div>
    </div>
  );
}

/** Yearly / All-Time: প্রথম ৬টি খাত দেখায়, বাকি সব আলাদা আলাদা কলাপসিবলে ("Others" বান্ডিল নয়)। items = সব খাত, বড় → ছোট। */
export function CategoryBarsMore({ items, onSelect, visible = 6 }: { items: readonly CategoryShare[]; onSelect?: (name: string) => void; visible?: number }) {
  const [open, setOpen] = useState(false);
  const rest = items.slice(visible);
  return (
    <div>
      <CategoryBars items={items.slice(0, visible)} onSelect={onSelect} />
      {rest.length > 0 && (
        <>
          <button
            type="button"
            aria-expanded={open}
            onClick={() => setOpen(!open)}
            className="mt-2 flex min-h-11 w-full items-center justify-center gap-1.5 rounded-xl bg-muted/10 text-xs font-medium text-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
          >
            {open ? 'Show less' : `Other categories (${rest.length})`}
            <ChevronDown aria-hidden size={14} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
          </button>
          {open && (
            <div className="mt-2">
              <CategoryBars items={rest} onSelect={onSelect} />
            </div>
          )}
        </>
      )}
    </div>
  );
}

// Spendee-স্টাইল donut: রিং-এর চারপাশে খাতের আইকন-বৃত্ত + শতাংশ; স্লাইস ট্যাপ করলে মাঝখানে সেই খাতের বিবরণ।
// ≥৩% ও পরস্পর ≥২০° দূরের স্লাইসেই লেবেল বসে (গাদাগাদি এড়াতে) — বাকি সবই নিচের তালিকায় আছে।
const DONUT = { cx: 150, cy: 116, r: 62, sw: 24 };
const LABEL_MIN_SHARE = 0.03;
const LABEL_MIN_GAP_DEG = 20;

/** ক্যাটাগরি-ওয়াইজ ব্যয়ের multi-colour donut — Home/Ledger আইকনের সাথে একই রঙ-হ্যাশ (categoryColorIndex)। */
export function CategoryDonut({ items, totalMinor }: { items: readonly CategoryShare[]; totalMinor: number }) {
  const [active, setActive] = useState<string | null>(null);
  if (items.length === 0) return null;
  const { cx, cy, r, sw } = DONUT;
  const circ = 2 * Math.PI * r;
  const sum = items.reduce((a, c) => a + c.totalMinor, 0);
  const gap = items.length > 1 ? 0.8 : 0;
  const summary = items.map((c) => `${c.name}: ${Math.round(c.share * 100)}%`).join(', ');

  let offset = 0;
  const slices = items.map((c) => {
    const len = c.share * circ;
    const s = { c, len, start: offset, theta: ((offset + len / 2) / circ) * 2 * Math.PI };
    offset += len;
    return s;
  });

  // বড় স্লাইস আগে — ছোটগুলো জায়গা না পেলে লেবেল ছাড়াই থাকে
  const placed: number[] = [];
  const labelled = new Set<string>();
  [...slices]
    .sort((x, y) => y.c.share - x.c.share)
    .forEach((s) => {
      if (s.c.share < LABEL_MIN_SHARE) return;
      const deg = (s.theta * 180) / Math.PI;
      const ok = placed.every((p) => {
        const d = Math.abs(p - deg) % 360;
        return Math.min(d, 360 - d) >= LABEL_MIN_GAP_DEG;
      });
      if (ok) {
        placed.push(deg);
        labelled.add(s.c.name);
      }
    });

  const R_ICON = r + sw / 2 + 16;
  const sel = active ? slices.find((s) => s.c.name === active) ?? null : null;
  const centerAmt = formatTakaWhole(sel ? sel.c.totalMinor : sum);
  const centerSize = centerAmt.length > 9 ? 12 : 15;
  const clip = (t: string, n: number) => (t.length > n ? `${t.slice(0, n - 1)}…` : t);

  return (
    <div className="flex justify-center py-1">
      <svg viewBox="0 0 300 232" className="w-full max-w-[340px]" aria-hidden>
        {slices.map(({ c, len, start }) => (
          <circle
            key={c.name}
            cx={cx}
            cy={cy}
            r={r}
            fill="none"
            stroke={`rgb(var(${chartVar(c.name)}))`}
            strokeWidth={active === c.name ? sw + 4 : sw}
            strokeDasharray={`${Math.max(0, len - gap).toFixed(2)} ${(circ - Math.max(0, len - gap)).toFixed(2)}`}
            strokeDashoffset={-start}
            transform={`rotate(-90 ${cx} ${cy})`}
            opacity={active && active !== c.name ? 0.3 : 1}
            style={{ cursor: 'pointer', transition: 'opacity 150ms' }}
            onClick={() => setActive(active === c.name ? null : c.name)}
          />
        ))}
        {slices.map(({ c, theta }) => {
          if (!labelled.has(c.name)) return null;
          const sin = Math.sin(theta);
          const cos = Math.cos(theta);
          const ix = cx + R_ICON * sin;
          const iy = cy - R_ICON * cos;
          const side = sin > 0.35 ? 'start' : sin < -0.35 ? 'end' : 'middle';
          const tx = side === 'middle' ? ix : side === 'start' ? ix + 15 : ix - 15;
          const ty = side === 'middle' ? (cos > 0 ? iy - 14 : iy + 20) : iy + 3.5;
          const v = `rgb(var(${chartVar(c.name)}))`;
          const dim = active && active !== c.name ? 0.35 : 1;
          return (
            <g key={c.name} opacity={dim} style={{ cursor: 'pointer', transition: 'opacity 150ms' }} onClick={() => setActive(active === c.name ? null : c.name)}>
              <circle cx={ix} cy={iy} r={11} fill={v} fillOpacity={0.18} stroke={v} strokeWidth={1} />
              <text x={ix} y={iy + 4} textAnchor="middle" fontSize={11}>{getCategoryIcon(c.name, 'expense')}</text>
              <text x={tx} y={ty} textAnchor={side} fontSize={10} fontWeight={600} className="fill-fg">
                {Math.round(c.share * 100)}%
              </text>
            </g>
          );
        })}
        <g style={{ cursor: active ? 'pointer' : 'default' }} onClick={() => setActive(null)}>
          <circle cx={cx} cy={cy} r={r - sw / 2 - 2} fill="transparent" />
          {sel ? (
            <>
              <text x={cx} y={cy - 12} textAnchor="middle" fontSize={9} className="fill-muted">{clip(sel.c.name, 14)}</text>
              <text x={cx} y={cy + 5} textAnchor="middle" fontSize={centerSize} fontWeight={700} className="fill-fg">{centerAmt}</text>
              <text x={cx} y={cy + 19} textAnchor="middle" fontSize={9} className="fill-muted">{Math.round(sel.c.share * 100)}%</text>
            </>
          ) : (
            <>
              <text x={cx} y={cy - 8} textAnchor="middle" fontSize={9} className="fill-muted">Total</text>
              <text x={cx} y={cy + 10} textAnchor="middle" fontSize={centerSize} fontWeight={700} className="fill-fg">{centerAmt}</text>
            </>
          )}
        </g>
      </svg>
      <span className="sr-only">Expense breakdown by category: {summary}. Total expense {formatAmount(totalMinor)}</span>
    </div>
  );
}

const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Income/Expense রঙ-চিহ্ন — কার্ডের শিরোনাম-সারির ডানে বসে (চার্টের নিচে আলাদা লাইন লাগে না)। */
export function IncomeExpenseLegend() {
  return (
    <span className="flex gap-3 text-[11px] text-muted" aria-hidden>
      <span><span className="text-income">■</span> Income</span>
      <span><span className="text-expense">■</span> Expense</span>
    </span>
  );
}

/** ১২ মাসের আয় (text-income) বনাম ব্যয় (text-expense) — grouped bars; মাস ট্যাপ করলে নিচে সংখ্যা দেখায়। */
export function IncomeExpenseBars({ rows }: { rows: readonly { yyyymm: string; incomeMinor: number; expenseMinor: number }[] }) {
  const gid = svgId(useId());
  const [sel, setSel] = useState<number | null>(null);
  const max = Math.max(1, ...rows.flatMap((r) => [r.incomeMinor, r.expenseMinor]));
  const H = 44;
  const summary = rows.map((r) => `${r.yyyymm}: income ${formatAmount(r.incomeMinor)}, expense ${formatAmount(r.expenseMinor)}`).join('; ');
  const picked = sel != null ? rows[sel] : null;
  const monthName = (yyyymm: string) => MONTH_SHORT[Number(yyyymm.slice(5, 7)) - 1] ?? yyyymm;
  return (
    <div>
      <svg viewBox="0 0 240 62" className="w-full" role="img" aria-label={`Monthly income and expense. ${summary}`}>
        <defs>
          <linearGradient id={`${gid}-income`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgb(var(--color-income))" stopOpacity={0.95} />
            <stop offset="100%" stopColor="rgb(var(--color-income))" stopOpacity={0.45} />
          </linearGradient>
          <linearGradient id={`${gid}-expense`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgb(var(--color-expense))" stopOpacity={0.95} />
            <stop offset="100%" stopColor="rgb(var(--color-expense))" stopOpacity={0.45} />
          </linearGradient>
        </defs>
        <line x1={0} y1={H + 1} x2={240} y2={H + 1} className="text-muted/30" stroke="currentColor" strokeWidth={0.5} />
        {rows.map((r, i) => {
          const x = i * 20 + 2;
          const hi = (r.incomeMinor / max) * H;
          const he = (r.expenseMinor / max) * H;
          const dim = sel != null && sel !== i ? 0.35 : 1;
          return (
            <g key={r.yyyymm} opacity={dim}>
              {sel === i && <rect x={x - 2} y={0} width={19} height={60} rx={2} className="fill-muted/10" />}
              <rect x={x} y={H - hi} width={7} height={hi} rx={1.5} fill={`url(#${gid}-income)`} />
              <rect x={x + 8} y={H - he} width={7} height={he} rx={1.5} fill={`url(#${gid}-expense)`} />
              <text x={x + 7.5} y={57} textAnchor="middle" fontSize={7} fontWeight={sel === i ? 700 : 400} className="fill-muted">
                {monthName(r.yyyymm)}
              </text>
            </g>
          );
        })}
      </svg>
      {/* ট্যাপ-লক্ষ্য: SVG-র ওপর অদৃশ্য ১২টা বাটন নয়, বরং আলাদা মাস-সারি (≥44px) — কীবোর্ড/স্ক্রিন-রিডারেও চলে */}
      <div role="group" aria-label="Select a month to see its numbers" className="mt-1 grid grid-cols-6 gap-1">
        {rows.map((r, i) => (
          <button
            key={r.yyyymm}
            type="button"
            aria-pressed={sel === i}
            onClick={() => setSel(sel === i ? null : i)}
            className={`min-h-11 rounded-lg text-[11px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary ${sel === i ? 'bg-primary/10 font-semibold text-primary' : 'bg-surface text-muted'}`}
          >
            {monthName(r.yyyymm)}
          </button>
        ))}
      </div>
      <p className="mt-2 min-h-5 text-xs text-muted" aria-live="polite">
        {picked ? (
          <>
            <span className="font-semibold text-fg">{monthName(picked.yyyymm)}</span> · <span className="text-income">Income {formatTakaWhole(picked.incomeMinor)}</span> · <span className="text-expense">Expense {formatTakaWhole(picked.expenseMinor)}</span>
          </>
        ) : (
          'Tap a month to see its numbers.'
        )}
      </p>
    </div>
  );
}

/** বছরভিত্তিক savings rate % — vertical bars, y=0 বেসলাইন (ঋণাত্মক rate নিচে); % বারের গায়ে, তাই আলাদা তালিকা নেই। */
export function SavingsRateBars({ items }: { items: readonly { year: number; pct: number }[] }) {
  const gid = svgId(useId());
  if (items.length === 0) return <p className="text-sm text-muted">Not enough data yet.</p>;
  const maxAbs = Math.max(1, ...items.map((i) => Math.abs(i.pct)));
  const W = 240;
  const mid = 32;
  const maxBar = 22;
  const slot = W / Math.max(items.length, 3);
  const x0 = (W - slot * items.length) / 2;
  const bw = Math.min(24, slot * 0.5);
  const summary = items.map((i) => `${i.year}: ${i.pct.toFixed(1)}%`).join('; ');
  return (
    <svg viewBox={`0 0 ${W} 74`} className="w-full" role="img" aria-label={`Savings rate by year. ${summary}`}>
      <defs>
        <linearGradient id={`${gid}-pos`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="rgb(var(--color-income))" stopOpacity={0.95} />
          <stop offset="100%" stopColor="rgb(var(--color-income))" stopOpacity={0.45} />
        </linearGradient>
        <linearGradient id={`${gid}-neg`} x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor="rgb(var(--color-expense))" stopOpacity={0.95} />
          <stop offset="100%" stopColor="rgb(var(--color-expense))" stopOpacity={0.45} />
        </linearGradient>
      </defs>
      <line x1={0} y1={mid} x2={W} y2={mid} className="text-muted/30" stroke="currentColor" strokeWidth={0.5} />
      {items.map((it, i) => {
        const barH = Math.max(1, (Math.abs(it.pct) / maxAbs) * maxBar);
        const cxm = x0 + i * slot + slot / 2;
        const pos = it.pct >= 0;
        return (
          <g key={it.year}>
            <rect x={cxm - bw / 2} y={pos ? mid - barH : mid} width={bw} height={barH} rx={1.5} fill={`url(#${gid}-${pos ? 'pos' : 'neg'})`} />
            <text x={cxm} y={pos ? mid - barH - 3 : mid + barH + 9} textAnchor="middle" fontSize={8} fontWeight={600} className="fill-fg">
              {it.pct.toFixed(1)}%
            </text>
            <text x={cxm} y={71} textAnchor="middle" fontSize={8} className="fill-muted">{it.year}</text>
          </g>
        );
      })}
    </svg>
  );
}

/** Net Worth Trend (G1): netWorthSnapshots-এর মাসিক Total Assets — pure-display line। Overview → All-Time-এ (owner-approved)। */
export function TrendLine({ points }: { points: readonly { yyyymm: string; valueMinor: number }[] }) {
  const gid = svgId(useId());
  if (points.length < 2) return <p className="text-sm text-muted">Trend appears after at least two monthly snapshots.</p>;
  const W = 240;
  const H = 90;
  const vals = points.map((p) => p.valueMinor);
  const lo = Math.min(...vals);
  const hi = Math.max(...vals);
  const span = hi - lo || 1;
  const xy = points.map((p, i) => [(i / (points.length - 1)) * (W - 8) + 4, H - 6 - ((p.valueMinor - lo) / span) * (H - 16)] as const);
  const areaPath = `M${xy.map(([x, y]) => `${x},${y}`).join(' L')} L${xy[xy.length - 1][0]},${H} L${xy[0][0]},${H} Z`;
  const summary = points.map((p) => `${p.yyyymm}: ${formatAmount(p.valueMinor)}`).join('; ');
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full text-primary" role="img" aria-label={`Net worth trend. ${summary}`}>
        <defs>
          <linearGradient id={`${gid}-area`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgb(var(--color-primary))" stopOpacity={0.28} />
            <stop offset="100%" stopColor="rgb(var(--color-primary))" stopOpacity={0} />
          </linearGradient>
        </defs>
        <path d={areaPath} fill={`url(#${gid}-area)`} />
        <polyline points={xy.map(([x, y]) => `${x},${y}`).join(' ')} fill="none" stroke="currentColor" strokeWidth={2} strokeLinejoin="round" />
        {xy.map(([x, y], i) => (
          <circle key={points[i].yyyymm} cx={x} cy={y} r={2.5} fill="currentColor" />
        ))}
      </svg>
      <p className="flex justify-between text-xs text-muted">
        <span>{points[0].yyyymm} · {formatTakaWhole(points[0].valueMinor)}</span>
        <span>{points[points.length - 1].yyyymm} · {formatTakaWhole(points[points.length - 1].valueMinor)}</span>
      </p>
    </div>
  );
}
