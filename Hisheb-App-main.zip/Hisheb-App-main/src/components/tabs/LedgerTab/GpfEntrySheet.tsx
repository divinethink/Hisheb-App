import { useState } from 'react';
import BottomSheet from '../../common/BottomSheet';
import AmountInput from '../../common/AmountInput';
import { resolveAmountMinor, minorToInput } from '../../../lib/money';
import { fiscalYearOf } from '../../../lib/gpfCalc';
import { addGpfEntry, updateGpfEntry } from '../../../data/gpfRepo';
import { settleOrPending } from '../../../lib/async';
import type { GpfEntry } from '../../../validation/gpfSchema';

type EntryType = GpfEntry['type'];
const TYPES: EntryType[] = ['contribution', 'interest', 'withdrawal'];

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function GpfEntrySheet({
  uid,
  editing,
  onClose,
}: {
  uid: string;
  editing?: GpfEntry;
  onClose: () => void;
}) {
  const [date, setDate] = useState(editing?.date ?? today());
  const [amount, setAmount] = useState(editing ? minorToInput(editing.amountMinor) : '');
  const [type, setType] = useState<EntryType>(editing?.type ?? 'contribution');
  const [note, setNote] = useState(editing?.note ?? '');
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const parsed = resolveAmountMinor(amount);

  async function save() {
    if (saving) return;
    setSubmitted(true);
    if (!date || parsed === null) return;
    setSaving(true);
    setError('');
    try {
      const fiscalYear = fiscalYearOf(date);
      if (editing) {
        await settleOrPending(updateGpfEntry(uid, editing.id, { date, amountMinor: parsed, type, note: note.trim(), fiscalYear }), 3000);
      } else {
        await settleOrPending(addGpfEntry(uid, { date, amountMinor: parsed, type, note: note.trim(), fiscalYear }), 3000);
      }
      onClose();
    } catch {
      setError('Could not save. Check your connection and try again.');
      setSaving(false);
    }
  }

  const footer = (
    <>
      <button type="button" onClick={onClose} disabled={saving} className="min-h-11 rounded-lg border border-muted/40 px-4 text-sm disabled:opacity-60">
        Cancel
      </button>
      <button type="button" onClick={() => void save()} disabled={saving} className="min-h-11 flex-1 rounded-lg bg-primary px-4 text-sm font-medium text-canvas disabled:opacity-60">
        {saving ? 'Saving…' : 'Save'}
      </button>
    </>
  );

  return (
    <BottomSheet title={editing ? 'Edit GPF entry' : 'Add GPF entry'} onRequestClose={onClose} footer={footer}>
      <div className="flex flex-col gap-4">
        <div className="flex gap-2">
          {TYPES.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setType(t)}
              aria-pressed={type === t}
              className={`min-h-11 flex-1 rounded-lg border text-sm capitalize ${type === t ? 'border-primary bg-primary/10 font-medium text-primary' : 'border-muted/40 text-muted'}`}
            >
              {t}
            </button>
          ))}
        </div>
        <AmountInput value={amount} onChange={setAmount} showError={submitted} />
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label htmlFor="gpf-date" className="mb-1 block text-sm text-muted">
              Date
            </label>
            <input
              id="gpf-date"
              type="date"
              lang="en-GB"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              aria-invalid={submitted && !date}
              className="min-h-12 w-full rounded-lg border border-muted/40 bg-surface px-3 text-fg outline-none"
            />
          </div>
          <div>
            <label htmlFor="gpf-note" className="mb-1 block text-sm text-muted">
              Note (optional)
            </label>
            <input
              id="gpf-note"
              value={note}
              maxLength={200}
              onChange={(e) => setNote(e.target.value)}
              className="min-h-12 w-full rounded-lg border border-muted/40 bg-surface px-3 text-fg outline-none"
            />
          </div>
        </div>
        {error && (
          <p role="alert" className="text-sm text-expense">
            {error}
          </p>
        )}
      </div>
    </BottomSheet>
  );
}
