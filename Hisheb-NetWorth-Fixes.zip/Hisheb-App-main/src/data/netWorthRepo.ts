// accountBalances + netWorthSnapshots repo — Architecture Plan §২.২ প্যাটার্ন।
// Composite doc-ID — একই account+মাস / মাসে সবসময় ঠিক একটা doc (C11/C12)। accountBalances পুরো replace; netWorthSnapshots merge (Excel-আনা `flow` মুছে না যায়)।
import { collection, deleteField, doc, getDocs, onSnapshot, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '../firebaseConfig';
import {
  AccountBalanceSchema,
  NetWorthSnapshotSchema,
  type AccountBalance,
  type NetWorthSnapshot,
  type SnapshotBreakdown,
  type SnapshotFlow,
} from '../validation/netWorthSchema';

const balCol = (uid: string) => collection(db, 'users', uid, 'accountBalances');
const snapCol = (uid: string) => collection(db, 'users', uid, 'netWorthSnapshots');

/** সব accountBalances doc — "latest per account" বের করা caller-এর দায়িত্ব (lib/netWorthCalc.ts, §২.২ safeParse)। */
export function subscribeAccountBalances(
  uid: string,
  onChange: (b: AccountBalance[]) => void,
  onInvalid?: (id: string) => void,
  onError?: (e: Error) => void,
) {
  return onSnapshot(
    balCol(uid),
    (snap) => {
      const out: AccountBalance[] = [];
      for (const d of snap.docs) {
        const r = AccountBalanceSchema.safeParse(d.data());
        if (!r.success) {
          onInvalid?.(d.id);
          continue;
        }
        out.push(r.data);
      }
      onChange(out);
    },
    onError,
  );
}

/** নতুন → পুরনো (yyyymm)। */
export function subscribeNetWorthSnapshots(
  uid: string,
  onChange: (s: NetWorthSnapshot[]) => void,
  onInvalid?: (id: string) => void,
  onError?: (e: Error) => void,
) {
  return onSnapshot(
    snapCol(uid),
    (snap) => {
      const out: NetWorthSnapshot[] = [];
      for (const d of snap.docs) {
        const r = NetWorthSnapshotSchema.safeParse(d.data());
        if (!r.success) {
          onInvalid?.(d.id);
          continue;
        }
        out.push(r.data);
      }
      out.sort((a, b) => b.yyyymm.localeCompare(a.yyyymm));
      onChange(out);
    },
    onError,
  );
}

/** doc-ID = `${accountId}_${yyyymm}` — same account+month চাপলে overwrite, নতুন doc কখনো না (C11)। */
export async function setAccountBalance(
  uid: string,
  accountId: string,
  yyyymm: string,
  balanceMinor: number,
  snapshotDate: string,
): Promise<void> {
  await setDoc(doc(balCol(uid), `${accountId}_${yyyymm}`), {
    accountId,
    yyyymm,
    balanceMinor,
    snapshotDate,
    updatedAt: serverTimestamp(),
  });
}

/** doc-ID = `yyyymm` — same month চাপলে একই doc update, নতুন doc কখনো না (C12)। **merge** — বিদ্যমান `flow` অক্ষত।
 *  total/snapshotDate/breakdown নতুন মানে বদলায়; unverified true না হলে পুরনো ফ্ল্যাগ মোছা হয় (deleteField),
 *  যাতে নতুন verified সেভে stale `unverified: true` না থাকে। */
export async function setNetWorthSnapshot(
  uid: string,
  yyyymm: string,
  totalAssetsMinor: number,
  snapshotDate: string,
  unverified?: boolean,
  breakdown?: SnapshotBreakdown,
): Promise<void> {
  await setDoc(doc(snapCol(uid), yyyymm), {
    yyyymm,
    totalAssetsMinor,
    snapshotDate,
    unverified: unverified ? true : deleteField(),
    ...(breakdown ? { breakdown } : {}),
    updatedAt: serverTimestamp(),
  }, { merge: true });
}

/** এক-বারের read — শুধু existing yyyymm-দের তালিকা (P4 monthly-backfill importer-এর overwrite-protection
 *  চেকের জন্য, one-shot getX প্যাটার্ন §২.২)। */
export async function getExistingNetWorthYyyymms(uid: string): Promise<string[]> {
  const snap = await getDocs(snapCol(uid));
  const out: string[] = [];
  for (const d of snap.docs) {
    const r = NetWorthSnapshotSchema.safeParse(d.data());
    if (r.success) out.push(r.data.yyyymm);
  }
  return out;
}

/** শুধু `breakdown` যোগ (merge) — total/snapshotDate/unverified অক্ষত। Excel backfill-এর জন্য; doc আগে থেকে থাকতে হবে। */
export async function setNetWorthBreakdown(uid: string, yyyymm: string, breakdown: SnapshotBreakdown): Promise<void> {
  await setDoc(doc(snapCol(uid), yyyymm), { breakdown, updatedAt: serverTimestamp() }, { merge: true });
}

/** শুধু `flow` (মাসের আয়/ব্যয়) যোগ (merge) — total/snapshotDate/breakdown অক্ষত। doc আগে থেকে থাকতে হবে। */
export async function setNetWorthFlow(uid: string, yyyymm: string, flow: SnapshotFlow): Promise<void> {
  await setDoc(doc(snapCol(uid), yyyymm), { flow, updatedAt: serverTimestamp() }, { merge: true });
}

/** এক-বারের read — সব বৈধ snapshot (backfill plan-এর জন্য)। */
export async function getNetWorthSnapshots(uid: string): Promise<NetWorthSnapshot[]> {
  const snap = await getDocs(snapCol(uid));
  const out: NetWorthSnapshot[] = [];
  for (const d of snap.docs) {
    const r = NetWorthSnapshotSchema.safeParse(d.data());
    if (r.success) out.push(r.data);
  }
  return out;
}
