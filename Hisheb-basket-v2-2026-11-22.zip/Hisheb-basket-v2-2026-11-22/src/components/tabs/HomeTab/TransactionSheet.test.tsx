// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

const repo = vi.hoisted(() => ({
  addTransaction: vi.fn().mockResolvedValue(undefined),
  updateTransaction: vi.fn().mockResolvedValue(undefined),
  addCategory: vi.fn().mockResolvedValue({ id: 'c-new', name: 'Books' }),
  addLabel: vi.fn().mockResolvedValue({ id: 'l-new', name: 'Gift' }),
}));
vi.mock('../../../data/transactionRepo', () => ({
  newTransactionId: () => 'new-id',
  addTransaction: repo.addTransaction,
  updateTransaction: repo.updateTransaction,
}));
vi.mock('../../../data/catalogRepo', () => ({ addCategory: repo.addCategory, addLabel: repo.addLabel }));
vi.mock('../../../hooks/useData', () => ({
  useSettings: () => ({ state: { status: 'ready', data: { largeAmountWarningThresholdMinor: null } }, retry: vi.fn() }),
}));

import TransactionSheet from './TransactionSheet';
import type { Category, Label } from '../../../validation/catalogSchemas';
import type { Transaction } from '../../../validation/transactionSchema';

const cat = (id: string, name: string, type: 'income' | 'expense' | null = null): Category => ({
  id, name, type, icon: null, color: null, archived: false, monthlyBudgetMinor: null, order: 0, createdAt: null, updatedAt: null,
});
const lbl = (id: string, name: string): Label => ({ id, name, icon: null, color: null, archived: false, order: 0, createdAt: null, updatedAt: null });
const cats = [cat('c1', 'Groceries', 'expense'), cat('c2', 'Salary', 'income')];
const lbls = [lbl('l1', 'Fruits')];

function setup(initial: Transaction | null = null, onDelete?: () => Promise<void>) {
  const onClose = vi.fn();
  render(
    <TransactionSheet uid="u1" initial={initial} categories={cats} labels={lbls} onClose={onClose} onDelete={onDelete} />,
  );
  return { onClose, user: userEvent.setup() };
}

// Transaction-এ Amount এখন native কীবোর্ড (২০২৬-১০-১৩) — user.type() দিয়ে টাইপ।
type TestUser = ReturnType<typeof userEvent.setup>;
async function typeAmount(user: TestUser, digits: string) {
  await user.type(screen.getByLabelText('Amount'), digits);
}
async function backspaceAmount(user: TestUser, times: number) {
  await user.type(screen.getByLabelText('Amount'), '{Backspace}'.repeat(times));
}

beforeEach(() => vi.clearAllMocks());
afterEach(cleanup);

describe('TransactionSheet', () => {
  it('shows validation errors and does not write when empty', async () => {
    // owner-request (২০২৬-০৯-২৬) category-first flow: Save বাটন শুধু category বাছার পরের
    // ধাপে (details) আসে, তাই "no category" validation এখন UI দিয়ে আর reachable না — সেই
    // চেক ইচ্ছাকৃতভাবে বাদ; amount-validation এখনো প্রযোজ্য।
    const { user } = setup();
    await user.click(screen.getByRole('button', { name: 'Groceries' }));
    await user.click(screen.getByRole('button', { name: /Next \(1\)/ }));
    await user.click(screen.getByRole('button', { name: 'Save' }));
    expect(screen.getByText(/greater than 0/)).toBeTruthy();
    expect(repo.addTransaction).not.toHaveBeenCalled();
  });

  it('"+" button adds amounts, keeps input focused, saves the sum', async () => {
    const { user, onClose } = setup();
    await user.click(screen.getByRole('button', { name: 'Groceries' }));
    await user.click(screen.getByRole('button', { name: /Next \(1\)/ }));
    await typeAmount(user, '500');
    await user.click(screen.getByRole('button', { name: 'Add' }));
    expect(document.activeElement).toBe(screen.getByLabelText('Amount'));
    await typeAmount(user, '120');
    expect((screen.getByLabelText('Amount') as HTMLInputElement).value).toBe('500+120');
    expect(screen.getByText('620')).toBeTruthy(); // বড় field-এ মোট
    await user.click(screen.getByRole('button', { name: 'Save' }));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
    expect(repo.addTransaction.mock.calls[0][2]).toMatchObject({ amountMinor: 62000 });
  });

  it('rejects zero amount', async () => {
    const { user } = setup();
    await user.click(screen.getByRole('button', { name: 'Groceries' }));
    await user.click(screen.getByRole('button', { name: /Next \(1\)/ }));
    await typeAmount(user, '0');
    await user.click(screen.getByRole('button', { name: 'Save' }));
    expect(repo.addTransaction).not.toHaveBeenCalled();
  });

  it('saves a valid expense with minor units, stable id, importKey null', async () => {
    const { user, onClose } = setup();
    await user.click(screen.getByRole('button', { name: 'Groceries' }));
    await user.click(screen.getByRole('button', { name: /Next \(1\)/ }));
    // owner সরাসরি "1250.5" টাইপ করবেন; ফলাফল amountMinor।
    await typeAmount(user, '1250.5');
    await user.click(screen.getByRole('button', { name: 'Fruits' }));
    await user.click(screen.getByRole('button', { name: 'Save' }));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
    expect(repo.addTransaction).toHaveBeenCalledTimes(1);
    const [uid, id, input] = repo.addTransaction.mock.calls[0];
    expect(uid).toBe('u1');
    expect(id).toBe('new-id');
    expect(input).toMatchObject({
      amountMinor: 125050, type: 'expense', categoryId: 'c1', categoryName: 'Groceries',
      labelIds: ['l1'], labelNames: ['Fruits'], importKey: null,
    });
    expect(input.occurredAt).toBeInstanceOf(Date);
  });

  it('hides categories of the other type and switches on type change', async () => {
    const { user } = setup();
    expect(screen.queryByRole('button', { name: 'Salary' })).toBeNull();
    await user.click(screen.getByRole('button', { name: 'income' }));
    expect(screen.getByRole('button', { name: 'Salary' })).toBeTruthy();
    expect(screen.queryByRole('button', { name: 'Groceries' })).toBeNull();
  });

  it('quick-adds a category (name only) and selects it', async () => {
    const { user } = setup();
    await user.click(screen.getByRole('button', { name: '+ New Category' }));
    await user.type(screen.getByLabelText('Name'), 'Books');
    await user.click(screen.getByRole('button', { name: 'Create' }));
    await waitFor(() =>
      expect(repo.addCategory).toHaveBeenCalledWith('u1', { name: 'Books', type: 'expense', icon: null, color: null }),
    );
    // quick-add category টিক-করা অবস্থায় যোগ হয়; Next (1) চাপলে amount/details ধাপ
    await user.click(await screen.findByRole('button', { name: /Next \(1\)/ }));
    expect(screen.getByLabelText('Amount')).toBeTruthy();
  });

  it('asks before discarding unsaved input', async () => {
    const { user, onClose } = setup();
    await user.click(screen.getByRole('button', { name: 'Groceries' }));
    await user.click(screen.getByRole('button', { name: /Next \(1\)/ }));
    await typeAmount(user, '50');
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(screen.getByText('Discard changes?')).toBeTruthy();
    expect(onClose).not.toHaveBeenCalled();
    await user.click(screen.getByRole('button', { name: 'Discard' }));
    expect(onClose).toHaveBeenCalled();
  });

  it('closes immediately when nothing changed', async () => {
    const { user, onClose } = setup();
    await user.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(onClose).toHaveBeenCalled();
  });

  it('edit mode updates (no add), keeps currency', async () => {
    const initial = {
      id: 't9', date: '2026-09-20', type: 'expense', occurredAt: { toDate: () => new Date() }, importKey: null,
      amountMinor: 50000, currency: 'BDT', categoryId: 'c1', categoryName: 'Groceries', labelIds: [], labelNames: [],
      note: '', deleted: false, createdAt: null, updatedAt: null, receiptUrl: null, recurringTemplateId: null,
    } as Transaction;
    const { user, onClose } = setup(initial);
    const amount = screen.getByLabelText('Amount') as HTMLInputElement;
    expect(amount.value).toBe('500');
    await backspaceAmount(user, amount.value.length);
    await typeAmount(user, '750');
    await user.click(screen.getByRole('button', { name: 'Save' }));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
    expect(repo.addTransaction).not.toHaveBeenCalled();
    expect(repo.updateTransaction).toHaveBeenCalledWith('u1', 't9', expect.objectContaining({ amountMinor: 75000, currency: 'BDT' }));
  });

  it('asks to confirm before calling onDelete, and shows error on failure', async () => {
    const initial = {
      id: 't9', date: '2026-09-20', type: 'expense', occurredAt: { toDate: () => new Date() }, importKey: null,
      amountMinor: 50000, currency: 'BDT', categoryId: 'c1', categoryName: 'Groceries', labelIds: [], labelNames: [],
      note: '', deleted: false, createdAt: null, updatedAt: null, receiptUrl: null, recurringTemplateId: null,
    } as Transaction;
    const onDelete = vi.fn().mockRejectedValueOnce(new Error('denied')).mockResolvedValueOnce(undefined);
    const { user } = setup(initial, onDelete);
    await user.click(screen.getByRole('button', { name: 'Delete transaction' }));
    expect(screen.getByText('Delete this transaction?')).toBeTruthy();
    await user.click(screen.getByRole('button', { name: 'Delete' }));
    await waitFor(() => expect(screen.getByText(/Could not delete/)).toBeTruthy());
    await user.click(screen.getByRole('button', { name: 'Delete transaction' }));
    await user.click(screen.getByRole('button', { name: 'Delete' }));
    await waitFor(() => expect(onDelete).toHaveBeenCalledTimes(2));
  });

  it('shows error and stays open when write fails', async () => {
    repo.addTransaction.mockRejectedValueOnce(new Error('denied'));
    const { user, onClose } = setup();
    await user.click(screen.getByRole('button', { name: 'Groceries' }));
    await user.click(screen.getByRole('button', { name: /Next \(1\)/ }));
    await typeAmount(user, '10');
    await user.click(screen.getByRole('button', { name: 'Save' }));
    await waitFor(() => expect(screen.getByText(/Could not save/)).toBeTruthy());
    expect(onClose).not.toHaveBeenCalled();
  });
});
