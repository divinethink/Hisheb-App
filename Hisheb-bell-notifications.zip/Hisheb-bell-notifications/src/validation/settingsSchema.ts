// settings/{doc} — সব ফিল্ড optional/nullable + default (defensive read, Roadmap Ai-নিয়ম E.4)।
// P1a-তে schema-তে থাকা নিশ্চিত করা হচ্ছে (B1, C4, G2, G3); UI/লজিক পরের Phase-এ।
import { z } from 'zod';
import { sanitizeLayout } from '../lib/overviewLayout';

const minorOrNull = z.number().int().positive().nullish().transform((v) => v ?? null);
const dateOrNull = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullish().transform((v) => v ?? null);

export const SettingsSchema = z.object({
  themeColor: z.string().default('blue'),
  displayMode: z.enum(['light', 'dark', 'sepia', 'system']).default('system'),
  dateFormat: z.enum(['dmy', 'mdy']).default('dmy'), // date display order (day/month/year vs month/day/year)
  reminderEnabled: z.boolean().default(true),
  appLockEnabled: z.boolean().default(false), // flag only — implement হচ্ছে না
  baseCurrency: z.string().default('BDT'),
  overallMonthlyBudgetMinor: minorOrNull, // B1
  savingsTargetPct: z.number().int().min(1).max(100).nullish().transform((v) => v ?? null), // Overview ধাপ ১: সঞ্চয়-হার টার্গেট % (null = ডিফল্ট ২০%)
  inflationPct: z.number().min(0).max(100).nullish().transform((v) => v ?? null), // Overview ধাপ ৩: মূল্যস্ফীতি % (আসল বৃদ্ধির জন্য; null = সেট করা হয়নি)
  essentialCategories: z.array(z.string().min(1).max(60)).max(50).nullish().transform((v) => v ?? []), // Overview আইডিয়া ৬: "প্রয়োজনীয় খাত" — ছোট-ফাঁক ও রিপোর্ট কার্ড থেকে বাদ (না থাকলে খালি)
  netWorthGoalMinor: minorOrNull, // Overview ধাপ ১: সম্পদ লক্ষ্য (null = ডিফল্ট ৳10,00,000)
  lastReminderShownDate: dateOrNull, // C4
  lastBudgetThresholdShownDate: dateOrNull, // C4
  lastBudgetThresholdShownLevel: z.enum(['70', '80', '90', '100']).nullish().transform((v) => v ?? null), // C4
  lastDueDateReminderShownDate: dateOrNull, // G2
  notificationsSeenKeys: z.array(z.string().max(120)).max(50).nullish().transform((v) => v ?? []), // Home বেল: যে নোটিফিকেশন দেখা হয়েছে (না থাকলে খালি; সব ডিভাইসে একই)
  largeAmountWarningThresholdMinor: minorOrNull, // G3 (null = ফিচার off)
  zakatNisabStandard: z.enum(['gold', 'silver']).nullish().transform((v) => v ?? null),
  zakatGoldPriceMinor: minorOrNull,
  zakatSilverPriceMinor: minorOrNull,
  zakatCalculationDate: dateOrNull,
  // Overview কাস্টমাইজ: ঐচ্ছিক; না থাকলে/অবৈধ হলে ডিফল্ট layout (আগের আচরণ)। sanitize lib/overviewLayout.ts-এ।
  overviewLayout: z.unknown().transform((v) => sanitizeLayout(v)),
  legacyAccessNote: z.string().nullish().transform((v) => v ?? null),
});
export type Settings = z.infer<typeof SettingsSchema>;
