import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, it } from 'vitest';
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
  type RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';

const OWNER_UID = 'owner-uid';
const OWNER_EMAIL = 'owner@example.com';
let env: RulesTestEnvironment;

const validTx = { amountMinor: 12500, type: 'expense', date: '2026-09-20' };

beforeAll(async () => {
  // OWNER_GMAIL placeholder-কে test-email দিয়ে বদলে আসল rules ফাইলই টেস্ট হয়
  const rules = readFileSync('firestore.rules', 'utf8').replaceAll('OWNER_GMAIL', OWNER_EMAIL);
  env = await initializeTestEnvironment({ projectId: 'demo-hisheb', firestore: { rules } });
});
afterAll(async () => env.cleanup());
beforeEach(async () => env.clearFirestore());

const owner = () =>
  env.authenticatedContext(OWNER_UID, { email: OWNER_EMAIL, email_verified: true }).firestore();

describe('Data isolation / access', () => {
  it('owner can create & read own transaction', async () => {
    const db = owner();
    await assertSucceeds(setDoc(doc(db, `users/${OWNER_UID}/transactions/t1`), validTx));
    await assertSucceeds(getDoc(doc(db, `users/${OWNER_UID}/transactions/t1`)));
  });
  it('owner cannot touch another uid path', async () => {
    const db = owner();
    await assertFails(setDoc(doc(db, 'users/other-uid/transactions/t1'), validTx));
    await assertFails(getDoc(doc(db, 'users/other-uid/transactions/t1')));
  });
  it('other Google account (different email/uid) is blocked', async () => {
    const db = env
      .authenticatedContext('stranger', { email: 'stranger@example.com', email_verified: true })
      .firestore();
    await assertFails(setDoc(doc(db, `users/${OWNER_UID}/transactions/t1`), validTx));
    await assertFails(getDoc(doc(db, `users/${OWNER_UID}/transactions/t1`)));
  });
  it('same uid but wrong email is blocked', async () => {
    const db = env
      .authenticatedContext(OWNER_UID, { email: 'x@example.com', email_verified: true })
      .firestore();
    await assertFails(getDoc(doc(db, `users/${OWNER_UID}/transactions/t1`)));
  });
  it('unverified email is blocked', async () => {
    const db = env
      .authenticatedContext(OWNER_UID, { email: OWNER_EMAIL, email_verified: false })
      .firestore();
    await assertFails(getDoc(doc(db, `users/${OWNER_UID}/transactions/t1`)));
  });
  it('unauthenticated is blocked', async () => {
    const db = env.unauthenticatedContext().firestore();
    await assertFails(getDoc(doc(db, `users/${OWNER_UID}/transactions/t1`)));
  });
  it('top-level collection and deeper subcollection are default-deny', async () => {
    const db = owner();
    await assertFails(setDoc(doc(db, 'transactions/t1'), validTx));
    await assertFails(setDoc(doc(db, `users/${OWNER_UID}/transactions/t1/sub/s1`), { a: 1 }));
  });
  it('unknown collection is denied, known free-form ones allowed', async () => {
    const db = owner();
    await assertFails(setDoc(doc(db, `users/${OWNER_UID}/randomStuff/x1`), { a: 1 }));
    await assertSucceeds(setDoc(doc(db, `users/${OWNER_UID}/accounts/a1`), { name: 'Cash' }));
    await assertSucceeds(setDoc(doc(db, `users/${OWNER_UID}/depositFunds/d1`), { name: 'Fund' }));
    await assertSucceeds(setDoc(doc(db, `users/${OWNER_UID}/settings/main`), { theme: 'dark' }));
  });
  it('owner can delete own doc', async () => {
    const db = owner();
    await assertSucceeds(setDoc(doc(db, `users/${OWNER_UID}/transactions/t1`), validTx));
    await assertSucceeds(deleteDoc(doc(db, `users/${OWNER_UID}/transactions/t1`)));
  });
});

describe('validWrite — amounts (R1: int, > 0)', () => {
  const path = `users/${OWNER_UID}/transactions/t1`;
  it.each([
    ['zero', 0],
    ['negative', -500],
    ['decimal', 12.5],
    ['string', '500'],
  ])('rejects %s amountMinor', async (_n, v) => {
    await assertFails(setDoc(doc(owner(), path), { ...validTx, amountMinor: v }));
  });
  it('rejects bad type', async () => {
    await assertFails(setDoc(doc(owner(), path), { ...validTx, type: 'transfer' }));
  });
  it.each(['2026-9-1', '20260901', 'not-a-date'])('rejects bad date %s', async (d) => {
    await assertFails(setDoc(doc(owner(), path), { ...validTx, date: d }));
  });
  it('rejects missing fields', async () => {
    await assertFails(setDoc(doc(owner(), path), { amountMinor: 100 }));
  });
  it('update to invalid amount is rejected too', async () => {
    const db = owner();
    await assertSucceeds(setDoc(doc(db, path), validTx));
    await assertFails(setDoc(doc(db, path), { ...validTx, amountMinor: -1 }));
  });
});

describe('validWrite — other collections (P3/P8-এর clause আগে থেকেই যাচাই)', () => {
  const p = (c: string) => doc(owner(), `users/${OWNER_UID}/${c}/x1`);
  it('debts/investments/homeDeposits/zakatPayments require positive int', async () => {
    await assertFails(setDoc(p('debts'), { totalAmountMinor: 0 }));
    await assertSucceeds(setDoc(p('debts'), { totalAmountMinor: 100 }));
    await assertFails(setDoc(p('investments'), { principalMinor: -1 }));
    await assertSucceeds(setDoc(p('investments'), { principalMinor: 100 }));
    await assertFails(setDoc(p('homeDeposits'), { amountMinor: 1.5 }));
    await assertSucceeds(setDoc(p('homeDeposits'), { amountMinor: 100 }));
    await assertFails(setDoc(p('zakatPayments'), { amountMinor: 0 }));
    await assertSucceeds(setDoc(p('zakatPayments'), { amountMinor: 100 }));
  });
  it('investments: optional company/round/platformNo fields are type-checked, old docs still pass', async () => {
    await assertSucceeds(setDoc(p('investments'), { principalMinor: 100 })); // পুরনো doc
    await assertSucceeds(
      setDoc(p('investments'), { principalMinor: 100, companyId: 'c1', round: 9, platformNo: '74874' }),
    );
    await assertSucceeds(setDoc(p('investments'), { principalMinor: 100, companyId: null, round: null }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, round: 0 }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, round: 1.5 }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, round: '9' }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, companyId: 5 }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, platformNo: 'x'.repeat(31) }));
  });
  it('investments: optional contractFileId/contractName are type-checked and size-limited', async () => {
    await assertSucceeds(setDoc(p('investments'), { principalMinor: 100, contractFileId: '1AbC', contractName: 'Agreement.pdf' }));
    await assertSucceeds(setDoc(p('investments'), { principalMinor: 100, contractFileId: null, contractName: null }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, contractFileId: 5 }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, contractFileId: 'x'.repeat(101) }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, contractName: 'x'.repeat(121) }));
    await assertFails(setDoc(p('investments'), { principalMinor: 100, contractName: 7 }));
  });
  it('investmentCompanies: name required, medium/logo limited', async () => {
    const logo = 'data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=';
    await assertSucceeds(setDoc(p('investmentCompanies'), { name: 'Apon Bazaar' }));
    await assertSucceeds(setDoc(p('investmentCompanies'), { name: 'Apon Bazaar', medium: 'biniyog.io', logo }));
    await assertSucceeds(setDoc(p('investmentCompanies'), { name: 'Apon Bazaar', medium: '', logo: null }));
    await assertFails(setDoc(p('investmentCompanies'), { name: '' }));
    await assertFails(setDoc(p('investmentCompanies'), { medium: 'biniyog.io' }));
    await assertFails(setDoc(p('investmentCompanies'), { name: 'x'.repeat(61) }));
    await assertFails(setDoc(p('investmentCompanies'), { name: 'A', medium: 'm'.repeat(61) }));
    await assertFails(setDoc(p('investmentCompanies'), { name: 'A', logo: 'https://evil.example/x.png' }));
    await assertFails(setDoc(p('investmentCompanies'), { name: 'A', logo: 'data:image/svg+xml;base64,PHN2Zz4=' }));
    await assertFails(setDoc(p('investmentCompanies'), { name: 'A', logo: 'data:image/webp;base64,' + 'A'.repeat(40000) }));
  });
  it('medPurchases need name, positive integer amount, YYYY-MM-DD date; text fields capped', async () => {
    const ok = { kind: 'medicine', name: 'Napa', dose: '500mg', amountMinor: 5000, date: '2026-11-22', patient: 'আমি', note: '' };
    await assertSucceeds(setDoc(p('medPurchases'), ok));
    await assertSucceeds(setDoc(p('medPurchases'), { name: 'CBC', amountMinor: 80000, date: '2026-01-05' }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, name: '' }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, name: 'x'.repeat(81) }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, amountMinor: 0 }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, amountMinor: 1.5 }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, date: '22/11/2026' }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, dose: 'd'.repeat(41) }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, patient: 'p'.repeat(41) }));
    await assertFails(setDoc(p('medPurchases'), { ...ok, note: 'n'.repeat(201) }));
  });
  it('marketGroups/marketItems need name; history is a list of at most 5', async () => {
    await assertSucceeds(setDoc(p('marketGroups'), { name: 'মশলা', icon: '🌶️', order: 100 }));
    await assertFails(setDoc(p('marketGroups'), { name: '' }));
    await assertFails(setDoc(p('marketGroups'), { name: 'x'.repeat(61) }));
    const item = { name: 'জিরা', groupId: 'g1', unit: 'কেজি', history: [] };
    await assertSucceeds(setDoc(p('marketItems'), item));
    await assertSucceeds(setDoc(p('marketItems'), { name: 'জিরা', groupId: 'g1' }));
    await assertFails(setDoc(p('marketItems'), { ...item, groupId: 5 }));
    await assertFails(setDoc(p('marketItems'), { ...item, name: '' }));
    await assertFails(setDoc(p('marketItems'), { ...item, unit: 'u'.repeat(21) }));
    await assertFails(setDoc(p('marketItems'), { ...item, history: 'x' }));
    const h = { date: '2026-11-01', priceMinor: 100, note: '' };
    await assertSucceeds(setDoc(p('marketItems'), { ...item, history: [h, h, h, h, h] }));
    await assertFails(setDoc(p('marketItems'), { ...item, history: [h, h, h, h, h, h] }));
  });
  it('customLedgers need a name and kind deposit|investment', async () => {
    await assertSucceeds(setDoc(p('customLedgers'), { name: 'Gold', kind: 'deposit' }));
    await assertSucceeds(setDoc(p('customLedgers'), { name: 'Share', kind: 'investment' }));
    await assertFails(setDoc(p('customLedgers'), { name: '', kind: 'deposit' }));
    await assertFails(setDoc(p('customLedgers'), { name: 'Gold' }));
    await assertFails(setDoc(p('customLedgers'), { name: 'Gold', kind: 'other' }));
  });
  it('gpfEntries require positive int amount and a known type', async () => {
    const ok = { amountMinor: 121300, type: 'contribution' };
    await assertSucceeds(setDoc(p('gpfEntries'), ok));
    await assertFails(setDoc(p('gpfEntries'), { ...ok, amountMinor: 0 }));
    await assertFails(setDoc(p('gpfEntries'), { ...ok, amountMinor: -5 }));
    await assertFails(setDoc(p('gpfEntries'), { ...ok, amountMinor: 1.5 }));
    await assertFails(setDoc(p('gpfEntries'), { ...ok, type: 'bonus' }));
  });
  it('accountBalances/netWorthSnapshots allow zero/negative int but not decimal', async () => {
    await assertSucceeds(setDoc(p('accountBalances'), { balanceMinor: -50 }));
    await assertSucceeds(setDoc(p('netWorthSnapshots'), { totalAssetsMinor: 0 }));
    await assertFails(setDoc(p('accountBalances'), { balanceMinor: 1.5 }));
    await assertFails(setDoc(p('netWorthSnapshots'), { totalAssetsMinor: 'a' }));
  });
  it('historicalYearlyTotals need int totals', async () => {
    const ok = { totalIncomeMinor: 100, totalExpenseMinor: 0, totalDepositMinor: 5 };
    await assertSucceeds(setDoc(p('historicalYearlyTotals'), ok));
    await assertFails(setDoc(p('historicalYearlyTotals'), { ...ok, totalIncomeMinor: 1.5 }));
    await assertFails(setDoc(p('historicalYearlyTotals'), { totalIncomeMinor: 1 }));
  });
  it('labels/categories need non-empty name', async () => {
    await assertFails(setDoc(p('labels'), { name: '' }));
    await assertSucceeds(setDoc(p('labels'), { name: 'Fruits' }));
    await assertFails(setDoc(p('categories'), { icon: 'x' }));
  });
});
